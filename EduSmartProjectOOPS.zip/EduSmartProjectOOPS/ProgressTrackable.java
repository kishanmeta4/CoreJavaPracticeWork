package EduSmartProjectOOPS;

public interface ProgressTrackable {
	void trackProgress();

}
