package EduSmartProjectOOPS;


  abstract class User{
	
	private String name;
	private String email;
	private String userid;
	
	  public User(String name,String email,String userid) {
		this.name=name;
		this.email=email;
		
		this.userid=userid;
		
	}
	

	public final void displayWelcom() {
		System.out.println("Welcome,"+ name +"i");	
	}
	
	public String getName() {
		return name;
	}
	public String getEmail() {
		return email;
	}
	public String getUserID() {
		return userid;
	}
	
	public abstract void viewProfile();
}

    class Student extends User implements ProgressTrackable
  {
	   private String enrolledCourse1;
	   private String enrolledCourse2;
	   
	    Student(String name, String email, String userid) {
		   super(name,email,userid);
		   
	   }
	  
	    public void enrollCourse(String courseName) {
	    	if (enrolledCourse1 == null) {
	    		
	    		enrolledCourse1 = courseName;
	    		
	    		System.out.println(getName() + " enrolled in " + courseName);
	    		
	    	}
	    	else if (enrolledCourse2 == null) {
	    		
	    		enrolledCourse2 = courseName;
	    		
	    		System.out.println(getName() + " enrolled in " + courseName);
	    		
	    	}
	    	else {
	    		System.out.println(getName() + " cannot enroll in more than 2 courses.");
	    	}
	    }
	    
	    
	    @Override
	    public void trackProgress() {
	    	System.out.println(getName() + " is tracking progress in enrolled courses.");
	    	
	    }
	    @Override
	    public void viewProfile() {
	    	System.out.println("Student Profile - Name: " +getName() + "Email: " + getEmail());
	    }
  }
  
   //instructor
    class Instructor extends User{
    	private String createdCourse1;
    	private String createdCourse2;
    	
    	public Instructor(String name, String email, String userid) {
    		
    		super(name,email,userid);
    	}
	   
    	public void createCourse(String courseName) {
    		if (createdCourse1 == null) {
    			
    			createdCourse1=courseName;
    			
    			System.out.println(getName() + "created course: " + courseName);
    		}
    		
    		else if (createdCourse2 == null) {
    			createdCourse2=courseName;
    			
    			System.out.println(getName() + "created course: " + courseName);
    		}
    		else {
    			System.out.println(getName() + "cannot create more than 2 course.");
    		}
    	}
	   
	    @Override
    	public void viewProfile() {
	    	System.out.println("Instructor Profile - Name: "+ getName() + "Email: " + getEmail());
    		
    	}
    	
   }
  
   
   class Admin extends User{
	   
	   public Admin(String name, String email, String userid) {
		   super(name,email,userid);
	   }
	   
	   public void removeUser(User user) {
		   System.out.println("Admin removed user: "+user.getName());
	   }
	   
	   @Override
	   public void viewProfile() {
		   System.out.println("Admin Profile - Name: "+ getName() + ", Email: " + getEmail());
	   }
   }

class Course{
	private String title;
	private int durationInHours;
	private final int maxStudents;
	
	public Course(String title, int durationInHours,int maxStudents) {
		this.title= title;
		this.durationInHours=durationInHours;
		this.maxStudents=maxStudents;
			
	}
	public Course(String title) {
		this(title, 0, 30);
		//defualt duration o hours and max 30 students
	}
	
	public void showCourseDetails() {
		System.out.println("Course: " + title + ", Duration: "+ durationInHours + " Hours, Max Students: " + maxStudents);
	
	}
}
   




public class EduSmartLMS{
	
	
	public static void main(String []args) {
		
		//create sudents
		Student s1 = new Student("kishan" ,"K@gmail.com","K002");
		Student s2 = new Student("Vishal" ,"V@gmail.com","V002");
		
		//Create Instructors
		Instructor i1= new Instructor("Prof. Bhavesh","Bhavesh@gmail.com","B001");
		Instructor i2= new Instructor("Prof. Nishat","Nishat@gmail.com","N001");
		
		//Create Admin
		
		Admin admin = new Admin("Admin Rushik","Admin@gmail.com","A001");
		
		//Instructors crate courses
		i1.createCourse("Java Basic");
		
		i1.createCourse("Advanced Java");
		
		i2.createCourse("Python Fundamentals");
		
		i2.createCourse("Data Structures");

		//Student enroll in course
		s1.enrollCourse("Java Basic");
		s1.enrollCourse("Data Structures");
		s1.enrollCourse("Python Fundamentals"); //should max limit message
		
		s2.enrollCourse("Python Fundamentals");
		
		//Display user profiles
		s1.viewProfile();
		s2.viewProfile();
		i1.viewProfile();
		i2.viewProfile();
		admin.viewProfile();
		
		//student track progress
		s1.trackProgress();
		s2.trackProgress();
		
		//admin removes a user
		admin.removeUser(s2);
		
		//create and display course
		Course c1 = new Course("Java Basic",40,50);
		
		Course c2 = new Course("Python Fundamentals");
		
		c1.showCourseDetails();
		c2.showCourseDetails();
		

		
		
		 
	}

}
